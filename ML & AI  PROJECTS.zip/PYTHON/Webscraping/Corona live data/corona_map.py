import pandas as pd
import matplotlib.pyplot as plt
import csv

with open('Corona_data.csv') as csv_file:
    csv_reader=csv.reader(csv_file)
    rows=list(csv_reader)

    x=rows[1]
    y=rows[2]
    z=rows[3]

    plt.title('Covid-19 Live Chart')
    plt.plot(z,y,x)

    plt.show()
