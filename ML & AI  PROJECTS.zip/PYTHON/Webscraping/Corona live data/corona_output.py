import tkinter
import csv
from tkinter import*

root=tkinter.Tk()
root.configure(bg='#4035B6')
root.title('Covid 19 Dash Board in India')
root.geometry('400x300+800+125')

lb1=tkinter.Label(root,width=20,height=2,text='Covid 19 Live Dashboard',bg='white',fg='red',font='sans 14').pack(fill='both')       


with open('Corona_Data.csv') as csv_file:
                  csv_reader=csv.reader(csv_file)
                  rows=list(csv_reader)

                  tc=rows[1]
                  td=rows[2]
                  tr=rows[3]

                  total_cases=tkinter.Label(root,width=20,height=2,text=tc,bg='orange',fg='blue',font='sans 14').pack(fill='both')            
                  total_deaths=tkinter.Label(root,width=20,height=2,text=td,bg='red',fg='white',font='sans 14').pack(fill='both')
                  total_recoveries=tkinter.Label(root,width=20,height=2,text=tr,bg='green',fg='white',font='sans 14').pack(fill='both')
                  btn=tkinter.Button(root,width=20,height=2,text='Close App',bg='red',fg='white',font='sans 14',command=root.destroy).pack(fill='both')  

root.mainloop()
                                                         












                  
