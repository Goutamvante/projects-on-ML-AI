import bs4
import pandas as pd
import requests

url='https://covidvax.live/location/ind'
result=requests.get(url)
soup=bs4.BeautifulSoup(result.text,'lxml')
cases=soup.find_all('table',class_='table table-striped')

data=[]
for i in cases:
    span=i.find('td')
    data.append(span.text.replace('\n',''))

print('Covid-19 live Vaccination detailed statistics[India]')
print('----------------------------------------------------------')
print('Total Doses:',data[0],end='\n')
print('People Vaccinated:',data[1],end='\n')
print('Completed Vaccinated:',data[2],end='\n')
print('Reported Doses:',data[3],end='\n')

df=pd.DataFrame({"Vaccine Data":data})
df.index=['Total Doses','People Vaccinated','Completed Vaccinated','Reported Doses','Updates','To','From']
df.to_csv('Vaccine_Data.csv')
