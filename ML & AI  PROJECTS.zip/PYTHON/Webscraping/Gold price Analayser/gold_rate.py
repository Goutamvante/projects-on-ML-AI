import bs4
import pandas as pd
import requests

url='https://www.goodreturns.in/gold-rates/chennai.html'
result=requests.get(url)
soup=bs4.BeautifulSoup(result.content,'lxml')
price=soup.find_all('div',{"id":"current-price"})
for pr in price:
    print("Price at Chennai:",pr.text)
txt1=pr.text

url='https://www.goodreturns.in/gold-rates/Mumbai.html'
result=requests.get(url)
soup=bs4.BeautifulSoup(result.content,'lxml')
price=soup.find_all('div',{"id":"current-price"})
for pr in price:
    print("Price at Mumbai:",pr.text)
txt2=pr.text

url='https://www.goodreturns.in/gold-rates/Kolkata.html'
result=requests.get(url)
soup=bs4.BeautifulSoup(result.content,'lxml')
price=soup.find_all('div',{"id":"current-price"})
for pr in price:
    print("Price at Kolkata:",pr.text)
txt3=pr.text

url='https://www.goodreturns.in/gold-rates/Delhi.html'
result=requests.get(url)
soup=bs4.BeautifulSoup(result.content,'lxml')
price=soup.find_all('div',{"id":"current-price"})
for pr in price:
    print("Price at Delhi:",pr.text)
txt4=pr.text

from tkinter import*
root=Tk()
root.title('Gold Price')
root.configure(bg='gold')
root.geometry('200x100')
Label(root,text='Chennai').grid(row=0,column=0)
w1=Label(root,text=txt1,bg='red',font='sans 14')
Label(root,text='Mumbai').grid(row=1,column=0)
w2=Label(root,text=txt2,bg='red',font='sans 14')
Label(root,text='Kolkata').grid(row=2,column=0)
w3=Label(root,text=txt3,bg='red',font='sans 14')
Label(root,text='Delhi').grid(row=3,column=0)
w4=Label(root,text=txt4,bg='red',font='sans 14')
b=Button(root,text='Close',fg='red',bg='yellow',command=root.destroy)
w1.grid(row=0,column=1)
w2.grid(row=1,column=1)
w3.grid(row=2,column=1)
w4.grid(row=3,column=1)
b.grid(row=4,column=1)
root.mainloop()
