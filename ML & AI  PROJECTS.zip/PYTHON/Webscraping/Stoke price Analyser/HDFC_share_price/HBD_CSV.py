import pandas as pd
import plotly.express as px
df=pd.read_csv('HBD.csv')
fig=px.line(df,x='HBD_x',y='HBD_y',title='HDFC Shares prices 2019-20')
fig.show()
