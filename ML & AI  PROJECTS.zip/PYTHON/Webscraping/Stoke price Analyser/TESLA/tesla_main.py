import tkinter as tk
from tkinter import messagebox
from tkinter import*
import os
import sys
root=tk.Tk()
root.geometry('450x450+0+0')
root.title('Tesla Stock Price Analysis')
root.configure(bg='khaki')

lb=tk.Label(root,text='Tesla Stock Price Analysis',font='sans 14',bg='#8207f5',fg='white').pack(fill='both')
lb3=tk.Label(root,text='Data Science App',font='sans 14',bg='#f0f288',fg='blue').pack(fill='both')

image=PhotoImage(file='ts.png')
lbi=Label(image=image)
lbi.pack()

def callRead():
    import tesla_stock_analysis as cl
b1=tk.Button(root,text='Tesla Stock Price Analysis',command=callRead,bg='#a67e07',fg='white',font='sans 14',height=2,width=26).pack()
b3=tk.Button(root,text='Close Application',command=root.destroy,bg='red',fg='white',font='sans 14',height=2,width=26).pack()
lb2=tk.Label(root,text='PREM_UDAYKAR',font='sans 14',bg='green',fg='white').pack(fill='both',side=tk.BOTTOM)

root.mainloop()
