import numpy as np
import pandas as pd
import plotly.express as px

data=pd.read_csv('TSLA.csv')
data.head()

close=data['Close']
ax=close.plot(title='Tesla')
set_xlabel=['Data']
set_ylabel=['Close']
fig=px.pie(values=set_xlabel,names=set_ylabel)
fig.show()

data['Date']=pd.to_datetime(data['Date'],infer_datetime_format=True)
data=data[['Date','Close']]
print(data)


'''model=Prophet()
model.fit(data)
predict=model.make_future_dataframe(periods=365)
forcast=model.predict(predict)
forcast[["ds", "yhat", "yhat_lower, "yhat_upper"]].tail()
'''
