import requests
from bs4 import BeautifulSoup

urls=["https://www.amazon.in","https://www.msn.com"]

for url in urls:
    r=requests.get(url)
    soup=BeautifulSoup(r.text,"html.parser")
    print("Title:%s"%soup.title.text)
