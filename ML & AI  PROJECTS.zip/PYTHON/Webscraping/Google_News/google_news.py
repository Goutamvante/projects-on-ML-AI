import bs4
import pandas as pd
import requests

url='https://news.google.com/topstories?hl=en-IN&gl=IN&ceid=IN:en'

result=requests.get(url)
soup=bs4.BeautifulSoup(result.content,'html.parser')

news=soup.find_all('div',class_='FVeGwb CVnAc Haq2Hf bWfURe')
for nw in news:
    print("Google News:",nw.text)
