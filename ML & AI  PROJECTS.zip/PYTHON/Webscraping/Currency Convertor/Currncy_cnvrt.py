#Currency converter
from forex_python.converter import CurrencyRates
import datetime

c=CurrencyRates()
dt=datetime.datetime(2022,3,17)

print('Now 1US$ is Equal:',c.get_rate('USD','INR',dt),'Indian Rupees')
print('Now 1Chinese CNY is Equal:',c.get_rate('CNY','INR',dt),'Indian Rupees')
print('Now 1GBP Pound is Equal:',c.get_rate('GBP','INR',dt),'Indian Rupees')
