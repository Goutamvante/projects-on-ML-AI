import bs4
import pandas as pd
import requests
url='https://www.flipkart.com/hp-ryzen-3-quad-core-5300u-8-gb-512-gb-ssd-windows-11-home-14s-fq1089au-thin-light-laptop/p/itm30e084d034979?pid=COMGAY9Y7WXZYFDA&lid=LSTCOMGAY9Y7WXZYFDAK13BGC&marketplace=FLIPKART&store=6bo%2Fb5g&srno=b_1_1&otracker=clp_banner_2_4.bannerX3.BANNER_electronics-big-savings-days-sale-store_JS865ENSH4AR&fm=neo%2Fmerchandising&iid=51b5baa9-ace2-4a83-b01a-b9936f486c7d.COMGAY9Y7WXZYFDA.SEARCH&ppt=clp&ppn=electronics-big-savings-days-sale-store&ssid=z419qimkn40000001647243279061'
result=requests.get(url)
soup=bs4.BeautifulSoup(result.content,'html.parser')
title=soup.find_all('h1',{"class":'yhB1nd'})
price=soup.find_all('div',{"class":"_30jeq3 _16Jk6d"})
rvw=soup.find_all('div',{"class":"row _3AjFsn _2c2kV-"})

for item in title:
    print('Title:',item.text)
for pr in price:
    print('Price:',pr.text)
for rv in rvw:
    print('Reviews:',rv.text)
