from translate import Translator
translator=Translator(to_lang="Hindi")
translation=translator.translate("Good Morning!")
print("Translated to:",translation)

fr=input("From Language:")
to=input("To Language:")
translator=Translator(from_lang=fr,to_lang=to)
txt=input("Enter Text:")
translation=translator.translate(txt)
print(translation)

