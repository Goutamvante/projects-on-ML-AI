import speech_recognition as sr
r=sr.Recognizer()
with sr.Microphone() as source:
    print('say something')
    audio=r.listen(source)
try:
    print("Speech was:"+r.recognize_google(audio,language="en-us",show_all=False))
except:
    print('something went wrong try again!')
