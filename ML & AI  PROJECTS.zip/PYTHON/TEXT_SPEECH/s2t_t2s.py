import tkinter as tk
import os
import sys
from PIL import ImageTk,Image
root=tk.Tk()
root.geometry('700x700+0+0')
root.title('Deep Learning Application')
root.configure(bg='white')

lb=tk.Label(root,text='Deep Learning Application',font='sans 14',bg='#8207f5',fg='white').pack(fill='both')
lb3=tk.Label(root,text='Sub-set of Machine Learning Application',font='sans 14',bg='#f0f288',fg='blue').pack(fill='both')

img=ImageTk.PhotoImage(Image.open("dl.jpg"))
lbi=tk.Label(root,image=img).pack()

def t2s():
    import text_speech as w
b4=tk.Button(root,text='Text to Speech',command=t2s,bg='blue',fg='white',font='sans 14',height=2,width=25).pack()

def s2t():
    import speech_rec as m
b3=tk.Button(root,text='Speech to Text',command=s2t,bg='teal',fg='white',font='sans 14',height=2,width=25).pack()

b6=tk.Button(root,text='Close Application',command=root.destroy,bg='red',fg='white',font='sans 14',height=2,width=25).pack()
lb2=tk.Label(root,text='',font='sans 14',bg='green',fg='white').pack(fill='both',side=tk.BOTTOM)





