import os
from gtts import gTTS
from pygame import mixer
mixer.init()
mytext=input('Enter any string:')
language='en'
myobj=gTTS(text=mytext, lang=language, slow=False)
myobj.save('welcome.mp3')
os.system('start welcom.mp3')
