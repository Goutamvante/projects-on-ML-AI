import tkinter as tk
import os
import sys
root=tk.Tk()
root.geometry('500x300+0+0')
root.title('OCR Main Application')
root.configure(bg='khaki')
lb=tk.Label(root,text='Machine Learning App to Extract Charecters from a Image',font='sans 14',bg='pink',fg='white').pack(fill='both')
lb3=tk.Label(root,text='A Deep Learning Application',font='sans 14',bg='green',fg='white').pack(fill='both')

def callGUI():
    import text_detect_GUI as tx
b2=tk.Button(root,text='Open Application',command=callGUI,bg='blue',fg='white',font='sans 14',height=2,width=20).pack()

def callRead():
    import readFile as rd
b3=tk.Button(root,text='Read Content',command=callRead,bg='yellow',fg='white',font='sans 14',height=2,width=20).pack()

b4=tk.Button(root,text='Close Application',command=root.destroy,bg='red',fg='white',font='sans 14',height=2,width=20).pack()

lb2=tk.Label(root,text='Developed by MIT India',font='sans 14',bg='green',fg='white').pack(fill='both',side=tk.BOTTOM)
