import pytesseract
import cv2
import tkinter as tk
from tkinter.filedialog import askopenfilename
root=tk.Tk()
Title=root.title("File Opener")
root.geometry('600x400+650+150')

def OpenFile():
    name=askopenfilename(initialdir="C:\python",filetypes=(("Image File","*.png"),("All Files","*.*")),title="Choose a file.")

    from PIL import Image
    pytesseract.pytesseract.tesseract_cmd="C:\Program Files (x86)\\Tesseract-OCR\\tesseract.exe"
    img=name
    t1=pytesseract.image_to_string(Image.open(img))

    file1=open('recognized.txt','w')
    file1.writelines(t1)
    file1.close()
    print("File created successfully!")

    print(t1)
    lb1=tk.Label(root,text='Extracted text is:',bg='cyan',fg='blue')
    lb2=tk.Label(root,text=t1,bg='white',fg='black',font='sans 14')
    lb1.pack(fill='both')
    lb2.pack(fill='both')

Label=tk.Label(root,text='OCR using Python',bg='khaki',fg='red',font=('Helvetica',16))
Label.pack(fill='both')
btn=tk.Button(root,text='Select an Image',bg='yellow',fg='blue',command=OpenFile,font='sans 12',height=2,width=20)
btn2=tk.Button(root,text='Close Application',bg='red',fg='yellow',command=root.destroy,font='sans 12',height=2,width=20)
btn.pack()
btn2.pack()




    
