import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox

def OpenFile():
    filename=filedialog.askopenfilename(initialdir="/",title='Open File',filetypes=(("Text File","*.txt"),("All Files","*.*")))

    try:
        if filename:
            the_file=open(filename)
            textArea.insert(tk.END,the_file.read())
            the_file.close()
        elif filename=='':
            messagebox.showinfo('Cancel','You clicked Cancel')

    except IOError:
        messagebox.showinfo('Error','Could not open file')

form=tk.Tk()
form.title("Read Text File")
form.geometry('600x450+650+150')
form.configure(bg='khaki')
b1=tk.Button(form,text='Select File (.txt)',command=OpenFile,bg='blue',fg='white',font='sans 12')
b1.pack()
textArea=tk.Text(form)
textArea.pack()
b2=tk.Button(form,text='Close window',command=form.destroy,bg='red',fg='white',font='sans 12')
b2.pack()







